// src/pages/Dashboard.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";
import ConfirmModal from "../components/ConfirmModal";

const CATS = ["needs", "wants", "debts", "savings", "invests"];

function formatIDR(n) {
  const x = Number(n || 0);
  try {
    return new Intl.NumberFormat("id-ID").format(x);
  } catch {
    return String(x);
  }
}

function cap(s) {
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

function Card({ title, children }) {
  return (
    <div
      style={{
        background: "rgba(255,255,255,0.06)",
        border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 16,
        padding: 16,
        boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
      }}
    >
      <div style={{ fontWeight: 800, marginBottom: 10 }}>{title}</div>
      {children}
    </div>
  );
}

function meterStatus(used, budget) {
  // khusus debts: kalau budget 0 tapi used > 0 => ada hutang
  if (budget <= 0 && used > 0) return "Ada hutang";
  if (used > budget) return "Over";
  if (budget > 0 && used >= 0.8 * budget) return "Waspada";
  return "Aman";
}

function Meter({ label, targetPct, income, spent }) {
  const budget = Math.round((Number(targetPct || 0) / 100) * Number(income || 0));

  // kalau budget 0 tapi ada pengeluaran (contoh debts), biar bar tetap keliatan
  const pctUsed =
    budget > 0
      ? Math.min(100, Math.round((spent / budget) * 100))
      : spent > 0
        ? 100
        : 0;

  const status = meterStatus(spent, budget);

  return (
    <div style={{ display: "grid", gap: 8 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
        <div style={{ fontWeight: 700 }}>
          {label}{" "}
          <span style={{ opacity: 0.75 }}>({targetPct}%)</span>
        </div>
        <div style={{ opacity: 0.85, fontSize: 13 }}>{status}</div>
      </div>

      <div
        style={{
          height: 12,
          borderRadius: 999,
          background: "rgba(255,255,255,0.12)",
          overflow: "hidden",
        }}
      >
        <div
          style={{
            width: `${pctUsed}%`,
            height: "100%",
            background: "linear-gradient(90deg, #7c3aed, #22c55e)",
          }}
        />
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          fontSize: 13,
          opacity: 0.9,
        }}
      >
        <div>Terpakai: Rp {formatIDR(spent)}</div>
        <div>Budget: Rp {formatIDR(budget)}</div>
      </div>
    </div>
  );
}

// logic target: kalau ada hutang, "debts" jadi 20% dan invests jadi 0%
// (biar nggak kejadian debts 0% padahal ada pengeluaran debt)
function computeTargets(hasDebt) {
  if (hasDebt) {
    return { needs: 50, wants: 15, debts: 20, savings: 15, invests: 0 };
  }
  return { needs: 50, wants: 15, debts: 0, savings: 15, invests: 20 };
}

function formatIDRShort(n) {
  const x = Number(n || 0);
  if (!Number.isFinite(x) || x <= 0) return "Rp 0";
  try {
    return `Rp ${new Intl.NumberFormat("id-ID").format(Math.floor(x))}`;
  } catch {
    return `Rp ${Math.floor(x)}`;
  }
}


export default function Dashboard() {
  const nav = useNavigate();

  // data core
  const [income, setIncome] = useState(0);
  const [summary, setSummary] = useState({
    needs: 0,
    wants: 0,
    debts: 0,
    savings: 0,
    invests: 0,
  });
  const [records, setRecords] = useState([]);

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  // input transaksi
  const [text, setText] = useState("");
  const [amount, setAmount] = useState("");

  // prediksi
  const [pred, setPred] = useState(null); // {category, confidence}
  const [chosenCat, setChosenCat] = useState("needs");
  const [busyPredict, setBusyPredict] = useState(false);
  const [busySave, setBusySave] = useState(false);

  // edit transaksi
  const [editingId, setEditingId] = useState(null);
  const [editDraft, setEditDraft] = useState({ text: "", amount: "", category: "needs" });
  const [busyEdit, setBusyEdit] = useState(false);
  const [busyDelete, setBusyDelete] = useState(false);

  // confirm modal controller
  const [confirm, setConfirm] = useState({
    open: false,
    title: "",
    message: null,
    confirmText: "Ya",
    cancelText: "Batal",
    danger: false,
    action: null, // async fn
  });

  function openConfirm({ title, message, confirmText, cancelText, danger, action }) {
    setConfirm({
      open: true,
      title: title || "Konfirmasi",
      message,
      confirmText: confirmText || "Ya",
      cancelText: cancelText || "Batal",
      danger: !!danger,
      action,
    });
  }

  function closeConfirm() {
    setConfirm((p) => ({ ...p, open: false, action: null }));
  }

  async function loadAll() {
    setErr("");
    setMsg("");
    setLoading(true);
    try {
      // income
      const inc = await api("/income", { method: "GET" });
      setIncome(Number(inc?.amount || 0));

      // summary
      const s = await api("/transactions/summary", { method: "GET" });
      setSummary({
        needs: Number(s?.needs || 0),
        wants: Number(s?.wants || 0),
        debts: Number(s?.debts || 0),
        savings: Number(s?.savings || 0),
        invests: Number(s?.invests || 0),
      });

      // records
      const list = await api("/transactions", { method: "GET" });
      setRecords(Array.isArray(list) ? list : []);
    } catch (e) {
      const m = e?.message || "Gagal load data";
      // kalau belum set income, backend balikin 404
      if (m.toLowerCase().includes("income not set") || m.toLowerCase().includes("404")) {
        // jangan asal redirect kalau error bukan income, tapi ini cukup aman buat case kamu
        // kalau mau lebih ketat, cek detail JSON backend
        nav("/setup-income");
        return;
      }
      setErr(m);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const hasDebt = (summary?.debts || 0) > 0;
  const targets = useMemo(() => computeTargets(hasDebt), [hasDebt]);

  const totalBudget = useMemo(() => {
    const t = targets || {};
    return Object.values(t).reduce(
      (acc, pct) => acc + Math.round((Number(pct || 0) / 100) * Number(income || 0)),
      0
    );
  }, [targets, income]);

  function logout() {
    localStorage.removeItem("token");
    nav("/login");
  }

  async function doPredictRequest() {
    setMsg("");
    setErr("");
    setPred(null);

    if (!text.trim()) {
      setErr("Tulis deskripsi transaksi dulu.");
      return;
    }

    setBusyPredict(true);
    try {
      const p = await api("/predict", {
        method: "POST",
        body: JSON.stringify({ text: text.trim() }),
      });
      setPred(p);
      setChosenCat(p?.category || "needs");
    } catch (e2) {
      setErr(e2?.message || "Predict gagal");
    } finally {
      setBusyPredict(false);
    }
  }

  async function saveTransactionRequest() {
    setMsg("");
    setErr("");

    const n = Number(amount);
    if (!text.trim()) {
      setErr("Teks transaksi kosong.");
      return;
    }
    if (!Number.isFinite(n) || n <= 0) {
      setErr("Nominal harus angka > 0.");
      return;
    }

    setBusySave(true);
    try {
      // NOTE: jangan kirim confidence kalau backend kamu tipenya int (biar gak 422)
      // kalau backend kamu sudah float, boleh kirim. Kita amanin: kirim null / undefined.
      await api("/transactions", {
        method: "POST",
        body: JSON.stringify({
          text: text.trim(),
          amount: Math.floor(n),
          category: chosenCat,
          // confidence: pred?.confidence ?? null,  // aktifin kalau schema backend sudah float
        }),
      });

      setMsg(`✅ Tersimpan ke ${chosenCat} (+Rp ${formatIDR(Math.floor(n))})`);

      setText("");
      setAmount("");
      setPred(null);

      await loadAll();
    } catch (e2) {
      setErr(e2?.message || "Gagal simpan transaksi");
    } finally {
      setBusySave(false);
    }
  }

  function startEdit(tx) {
    setErr("");
    setMsg("");
    setEditingId(tx.id);
    setEditDraft({
      text: tx.text ?? "",
      amount: String(tx.amount ?? ""),
      category: tx.category ?? "needs",
    });
  }

  function cancelEdit() {
    setEditingId(null);
    setEditDraft({ text: "", amount: "", category: "needs" });
  }

  async function updateTransactionRequest(txId) {
    setErr("");
    setMsg("");

    const n = Number(editDraft.amount);
    if (!editDraft.text.trim()) return setErr("Teks transaksi kosong.");
    if (!Number.isFinite(n) || n <= 0) return setErr("Nominal harus angka > 0.");
    if (!CATS.includes(editDraft.category)) return setErr("Kategori tidak valid.");

    setBusyEdit(true);
    try {
      await api(`/transactions/${txId}`, {
        method: "PUT",
        body: JSON.stringify({
          text: editDraft.text.trim(),
          amount: Math.floor(n),
          category: editDraft.category,
        }),
      });
      setMsg("✅ Transaksi berhasil diupdate");
      cancelEdit();
      await loadAll();
    } catch (e) {
      setErr(e?.message || "Gagal update transaksi");
    } finally {
      setBusyEdit(false);
    }
  }

  async function deleteTransactionRequest(txId) {
    setErr("");
    setMsg("");

    setBusyDelete(true);
    try {
      await api(`/transactions/${txId}`, { method: "DELETE" });
      setMsg("✅ Transaksi berhasil dihapus");
      if (editingId === txId) cancelEdit();
      await loadAll();
    } catch (e) {
      setErr(e?.message || "Gagal hapus transaksi");
    } finally {
      setBusyDelete(false);
    }
  }

  // UI helpers
  const pageStyle = {
    minHeight: "100vh",
    padding: 24,
    color: "#fff",
    background:
      "radial-gradient(1200px 600px at 20% 10%, rgba(124,58,237,0.35), transparent), radial-gradient(1200px 600px at 90% 10%, rgba(34,197,94,0.25), transparent), #0b1020",
  };

  const pillStyle = (type) => {
    const isErr = type === "err";
    const isOk = type === "ok";
    return {
      padding: 12,
      borderRadius: 12,
      border: isErr
        ? "1px solid rgba(239,68,68,0.35)"
        : isOk
          ? "1px solid rgba(34,197,94,0.35)"
          : "1px solid rgba(255,255,255,0.12)",
      background: isErr
        ? "rgba(239,68,68,0.12)"
        : isOk
          ? "rgba(34,197,94,0.12)"
          : "rgba(0,0,0,0.18)",
      color: isErr ? "#fecaca" : isOk ? "#bbf7d0" : "#fff",
    };
  };

  const inputStyle = {
    padding: 12,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(255,255,255,0.06)",
    color: "#fff",
    outline: "none",
  };

  const btnStyle = (variant = "soft") => {
    if (variant === "primary") {
      return {
        padding: 12,
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.18)",
        background: "linear-gradient(90deg, rgba(124,58,237,0.9), rgba(34,197,94,0.8))",
        color: "#fff",
        cursor: "pointer",
        fontWeight: 900,
      };
    }
    if (variant === "danger") {
      return {
        padding: "10px 12px",
        borderRadius: 12,
        border: "1px solid rgba(255,255,255,0.18)",
        background: "rgba(239,68,68,0.15)",
        color: "#fff",
        cursor: "pointer",
        fontWeight: 900,
      };
    }
    return {
      padding: "10px 12px",
      borderRadius: 12,
      border: "1px solid rgba(255,255,255,0.18)",
      background: "rgba(255,255,255,0.06)",
      color: "#fff",
      cursor: "pointer",
      fontWeight: 800,
    };
  };

  return (
    <div style={pageStyle}>
      <div style={{ maxWidth: 1100, margin: "0 auto", display: "grid", gap: 16 }}>
        {/* header */}
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <div>
            <div style={{ opacity: 0.8, fontSize: 13 }}>Financial Planning</div>
            <h1 style={{ margin: "6px 0 0", fontSize: 34 }}>Dashboard</h1>
          </div>

          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <button onClick={() => nav("/setup-income")} style={btnStyle("soft")}>
              Edit Income
            </button>
            <button onClick={logout} style={btnStyle("soft")}>
              Logout
            </button>
          </div>
        </div>

        {/* alerts */}
        {err && <div style={pillStyle("err")}>{err}</div>}
        {msg && <div style={pillStyle("ok")}>{msg}</div>}

        {/* top cards */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <Card title="Income Bulanan">
            <div style={{ fontSize: 28, fontWeight: 900 }}>Rp {formatIDR(income)}</div>
            <div style={{ opacity: 0.75, marginTop: 6, fontSize: 13 }}>
              Total budget (berdasarkan target): Rp {formatIDR(totalBudget)}
            </div>
            {hasDebt && (
              <div style={{ marginTop: 10, fontSize: 13, opacity: 0.9 }}>
                ⚠️ Terdeteksi hutang → target <b>Debts 20%</b>, <b>Invests 0%</b>
              </div>
            )}
          </Card>

          <Card title="Input Transaksi">
            <form
              onSubmit={async (e) => {
                e.preventDefault();
                // ✅ TANPA KONFIRMASI PREDICT: langsung predict
                await doPredictRequest();
              }}
              style={{ display: "grid", gap: 10 }}
            >
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder='contoh: "bayar cicilan mobil"'
                style={inputStyle}
              />


              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder='nominal (contoh: 250000)'
                inputMode="numeric"
                style={inputStyle}
              />
              <div style={{ fontSize: 13, opacity: 0.85, marginTop: -4 }}>
                Preview: <b>{formatIDRShort(amount)}</b>
              </div>

              <button disabled={busyPredict} style={{ ...btnStyle("soft"), opacity: busyPredict ? 0.7 : 1 }}>
                {busyPredict ? "Predicting..." : "Predict Category"}
              </button>

              {pred && (
                <div
                  style={{
                    marginTop: 6,
                    padding: 12,
                    borderRadius: 12,
                    border: "1px solid rgba(255,255,255,0.12)",
                    background: "rgba(0,0,0,0.18)",
                    display: "grid",
                    gap: 10,
                  }}
                >
                  <div style={{ fontSize: 13, opacity: 0.9 }}>
                    Prediksi: <b>{pred.category}</b>{" "}
                    {pred.confidence != null && (
                      <span>(conf {Math.round((pred.confidence || 0) * 100)}%)</span>
                    )}
                  </div>

                  <div style={{ display: "grid", gap: 6 }}>
                    <div style={{ fontSize: 13, opacity: 0.85 }}>Edit kategori</div>
                    <select
                      value={chosenCat}
                      onChange={(e) => setChosenCat(e.target.value)}
                      style={{
                        padding: 10,
                        borderRadius: 12,
                        border: "1px solid rgba(255,255,255,0.18)",
                        background: "rgba(255,255,255,0.06)",
                        color: "#fff",
                        outline: "none",
                      }}
                    >
                      {CATS.map((c) => (
                        <option key={c} value={c} style={{ color: "#000" }}>
                          {cap(c)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      // KONFIRMASI SEBELUM SIMPAN (tetap ada)
                      openConfirm({
                        title: "Simpan transaksi?",
                        message: (
                          <div style={{ display: "grid", gap: 10 }}>
                            <div style={{ opacity: 0.85 }}>
                              Pastikan data sudah benar sebelum disimpan.
                            </div>
                            <div
                              style={{
                                padding: 12,
                                borderRadius: 12,
                                background: "rgba(255,255,255,0.06)",
                                border: "1px solid rgba(255,255,255,0.12)",
                              }}
                            >
                              <div>
                                <b>Teks:</b> {text || "-"}
                              </div>
                              <div>
                                <b>Nominal:</b> Rp {formatIDR(Number(amount || 0))}
                              </div>
                              <div>
                                <b>Kategori:</b> {chosenCat}
                              </div>
                              {pred?.confidence != null && (
                                <div>
                                  <b>Confidence:</b> {Math.round((pred.confidence || 0) * 100)}%
                                </div>
                              )}
                            </div>
                          </div>
                        ),
                        confirmText: "Ya, simpan",
                        cancelText: "Batal",
                        action: async () => {
                          await saveTransactionRequest();
                        },
                      });
                    }}
                    disabled={busySave}
                    style={{ ...btnStyle("primary"), opacity: busySave ? 0.7 : 1 }}
                  >
                    {busySave ? "Saving..." : "Konfirmasi & Simpan"}
                  </button>
                </div>
              )}
            </form>
          </Card>
        </div>

        {/* meters */}
        <Card title="Budget Meters">
          {loading ? (
            <div style={{ opacity: 0.75 }}>Loading...</div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <Meter label="Needs" targetPct={targets.needs} income={income} spent={summary.needs} />
              <Meter label="Wants" targetPct={targets.wants} income={income} spent={summary.wants} />
              <Meter label="Debts" targetPct={targets.debts} income={income} spent={summary.debts} />
              <Meter label="Savings" targetPct={targets.savings} income={income} spent={summary.savings} />
              <Meter label="Invests" targetPct={targets.invests} income={income} spent={summary.invests} />
            </div>
          )}
        </Card>

        {/* records */}
        <Card title="Riwayat Transaksi (bisa edit & hapus)">
          {records.length === 0 ? (
            <div style={{ opacity: 0.75 }}>Belum ada transaksi.</div>
          ) : (
            <div style={{ display: "grid", gap: 10 }}>
              {records.map((tx) => {
                const isEditing = editingId === tx.id;

                return (
                  <div
                    key={tx.id}
                    style={{
                      padding: 12,
                      borderRadius: 14,
                      border: "1px solid rgba(255,255,255,0.12)",
                      background: "rgba(0,0,0,0.16)",
                      display: "grid",
                      gap: 10,
                    }}
                  >
                    {!isEditing ? (
                      <>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
                          <div style={{ fontWeight: 800 }}>
                            {tx.text}
                            <span style={{ opacity: 0.7, fontWeight: 600 }}> — {cap(tx.category)}</span>
                          </div>
                          <div style={{ fontWeight: 900 }}>Rp {formatIDR(tx.amount)}</div>
                        </div>

                        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-end" }}>
                          <button onClick={() => startEdit(tx)} style={btnStyle("soft")}>
                            Edit
                          </button>
                          <button
                            disabled={busyDelete}
                            onClick={() => {
                              // KONFIRMASI DELETE
                              openConfirm({
                                title: "Hapus transaksi?",
                                danger: true,
                                confirmText: "Ya, hapus",
                                cancelText: "Batal",
                                message: (
                                  <div style={{ display: "grid", gap: 10 }}>
                                    <div style={{ opacity: 0.9 }}>
                                      Kamu yakin mau hapus transaksi ini?
                                    </div>
                                    <div
                                      style={{
                                        padding: 12,
                                        borderRadius: 12,
                                        background: "rgba(255,255,255,0.06)",
                                        border: "1px solid rgba(255,255,255,0.12)",
                                      }}
                                    >
                                      <div><b>Teks:</b> {tx.text}</div>
                                      <div><b>Nominal:</b> Rp {formatIDR(tx.amount)}</div>
                                      <div><b>Kategori:</b> {tx.category}</div>
                                    </div>
                                  </div>
                                ),
                                action: async () => {
                                  await deleteTransactionRequest(tx.id);
                                },
                              });
                            }}
                            style={{ ...btnStyle("danger"), opacity: busyDelete ? 0.7 : 1 }}
                          >
                            Hapus
                          </button>
                        </div>
                      </>
                    ) : (
                      <>
                        <div style={{ display: "grid", gap: 10 }}>
                          <input
                            value={editDraft.text}
                            onChange={(e) => setEditDraft((p) => ({ ...p, text: e.target.value }))}
                            style={inputStyle}
                            placeholder="Deskripsi transaksi"
                          />
                          <input
                            value={editDraft.amount}
                            onChange={(e) => setEditDraft((p) => ({ ...p, amount: e.target.value }))}
                            style={inputStyle}
                            inputMode="numeric"
                            placeholder="Nominal"
                          />

                          <select
                            value={editDraft.category}
                            onChange={(e) => setEditDraft((p) => ({ ...p, category: e.target.value }))}
                            style={{
                              padding: 10,
                              borderRadius: 12,
                              border: "1px solid rgba(255,255,255,0.18)",
                              background: "rgba(255,255,255,0.06)",
                              color: "#fff",
                              outline: "none",
                            }}
                          >
                            {CATS.map((c) => (
                              <option key={c} value={c} style={{ color: "#000" }}>
                                {cap(c)}
                              </option>
                            ))}
                          </select>

                          <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", flexWrap: "wrap" }}>
                            <button onClick={cancelEdit} style={btnStyle("soft")}>
                              Batal
                            </button>

                            <button
                              disabled={busyEdit}
                              onClick={() => {
                                // KONFIRMASI EDIT
                                openConfirm({
                                  title: "Simpan perubahan?",
                                  confirmText: "Ya, update",
                                  cancelText: "Batal",
                                  message: (
                                    <div style={{ display: "grid", gap: 10 }}>
                                      <div style={{ opacity: 0.85 }}>
                                        Ini akan mengubah transaksi yang sudah tersimpan.
                                      </div>
                                      <div
                                        style={{
                                          padding: 12,
                                          borderRadius: 12,
                                          background: "rgba(255,255,255,0.06)",
                                          border: "1px solid rgba(255,255,255,0.12)",
                                        }}
                                      >
                                        <div><b>Teks:</b> {editDraft.text || "-"}</div>
                                        <div><b>Nominal:</b> Rp {formatIDR(Number(editDraft.amount || 0))}</div>
                                        <div><b>Kategori:</b> {editDraft.category}</div>
                                      </div>
                                    </div>
                                  ),
                                  action: async () => {
                                    await updateTransactionRequest(tx.id);
                                  },
                                });
                              }}
                              style={{ ...btnStyle("primary"), opacity: busyEdit ? 0.7 : 1 }}
                            >
                              {busyEdit ? "Updating..." : "Update"}
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      {/* confirm modal global */}
      <ConfirmModal
        open={confirm.open}
        title={confirm.title}
        message={confirm.message}
        confirmText={confirm.confirmText}
        cancelText={confirm.cancelText}
        danger={confirm.danger}
        onCancel={closeConfirm}
        onConfirm={async () => {
          const act = confirm.action;
          closeConfirm();
          if (typeof act === "function") {
            await act();
          }
        }}
      />
    </div>
  );
}
