// src/pages/Dashboard.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../api";
import ConfirmModal from "../components/ConfirmModal";

const CATS = ["needs", "wants", "debts", "savings", "invests"];

function formatIDR(n) {
  const x = Number(n || 0);
  try {
    return new Intl.NumberFormat("id-ID").format(x);
  } catch {
    return String(x);
  }
}

function cap(s) {
  return s ? s[0].toUpperCase() + s.slice(1) : s;
}

function Card({ title, children }) {
  return (
    <div
      style={{
        background: "rgba(255,255,255,0.06)",
        border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 16,
        padding: 16,
        boxShadow: "0 10px 30px rgba(0,0,0,0.25)",
      }}
    >
      <div style={{ fontWeight: 900, marginBottom: 12 }}>{title}</div>
      {children}
    </div>
  );
}

function Meter({ label, targetPct, income, spent }) {
  const budget = Math.floor((Number(income || 0) * Number(targetPct || 0)) / 100);
  const used = Number(spent || 0);
  const pct = budget > 0 ? Math.min(100, Math.round((used / budget) * 100)) : 0;
  const status = used > budget ? "Bahaya" : "Aman";

  return (
    <div
      style={{
        padding: 14,
        borderRadius: 16,
        border: "1px solid rgba(255,255,255,0.12)",
        background: "rgba(0,0,0,0.16)",
        display: "grid",
        gap: 10,
      }}
    >
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div style={{ fontWeight: 900 }}>
          {label} <span style={{ opacity: 0.75 }}>({targetPct}%)</span>
        </div>
        <div style={{ fontWeight: 800, opacity: 0.85 }}>{status}</div>
      </div>

      <div
        style={{
          height: 10,
          borderRadius: 999,
          background: "rgba(255,255,255,0.10)",
          overflow: "hidden",
          border: "1px solid rgba(255,255,255,0.12)",
        }}
      >
        <div
          style={{
            height: "100%",
            width: `${pct}%`,
            background: "linear-gradient(90deg, rgba(124,58,237,0.9), rgba(34,197,94,0.8))",
          }}
        />
      </div>

      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", fontSize: 13 }}>
        <div style={{ opacity: 0.85 }}>Terpakai: Rp {formatIDR(used)}</div>
        <div style={{ opacity: 0.85 }}>Budget: Rp {formatIDR(budget)}</div>
      </div>
    </div>
  );
}

function pad2(n) {
  return String(n).padStart(2, "0");
}

export default function Dashboard() {
  const nav = useNavigate();

  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [msg, setMsg] = useState("");

  // ✅ user dari DB
  const [me, setMe] = useState(null); // {id, username, email}

  const [income, setIncome] = useState(0);
  const [targets, setTargets] = useState({
    needs: 50,
    wants: 15,
    debts: 0,
    savings: 15,
    invests: 20,
  });

  const [summary, setSummary] = useState({
    needs: 0,
    wants: 0,
    debts: 0,
    savings: 0,
    invests: 0,
  });

  // ✅ pilih bulan (buat simulasi & hitung bulanan)
  const now = new Date();
  const [ym, setYm] = useState(`${now.getFullYear()}-${pad2(now.getMonth() + 1)}`); // YYYY-MM

  // input transaksi
  const [text, setText] = useState("");
  const [amount, setAmount] = useState("");
  const [pred, setPred] = useState(null);
  const [chosenCat, setChosenCat] = useState("needs");
  const [busyPredict, setBusyPredict] = useState(false);
  const [busySave, setBusySave] = useState(false);

  // confirm modal
  const [confirm, setConfirm] = useState({
    open: false,
    title: "",
    message: null,
    confirmText: "Ya",
    cancelText: "Batal",
    danger: false,
    action: null,
  });

  function openConfirm({ title, message, confirmText, cancelText, danger, action }) {
    setConfirm({
      open: true,
      title: title || "Konfirmasi",
      message,
      confirmText: confirmText || "Ya",
      cancelText: cancelText || "Batal",
      danger: !!danger,
      action,
    });
  }

  function closeConfirm() {
    setConfirm((p) => ({ ...p, open: false, action: null }));
  }

  const totalBudget = useMemo(() => {
    const inc = Number(income || 0);
    const sumPct =
      Number(targets.needs || 0) +
      Number(targets.wants || 0) +
      Number(targets.debts || 0) +
      Number(targets.savings || 0) +
      Number(targets.invests || 0);
    return Math.floor((inc * sumPct) / 100);
  }, [income, targets]);

  const hasDebt = useMemo(() => Number(summary.debts || 0) > 0, [summary.debts]);

  function ymToYearMonth(ymStr) {
    const [y, m] = String(ymStr || "").split("-");
    return { year: Number(y), month: Number(m) };
  }

  async function loadAll() {
    setLoading(true);
    setErr("");
    setMsg("");

    try {
      // ✅ ambil user dari DB
      const meRes = await api("/me", { method: "GET" });
      setMe(meRes);

      // ✅ dashboard per-bulan: backend baca query year & month
      const { year, month } = ymToYearMonth(ym);
      const d = await api(`/dashboard?year=${year}&month=${month}`, { method: "GET" });

      setIncome(Number(d?.income || 0));
      setTargets(d?.targets || targets);
      setSummary(d?.spent || summary);
    } catch (e2) {
      setErr(e2?.message || "Gagal load dashboard");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ✅ tiap ganti bulan -> reload (pemakaian otomatis “reset” karena query-nya beda bulan)
  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ym]);

  function logout() {
    localStorage.removeItem("token");
    nav("/login");
  }

  async function doPredictRequest() {
    setMsg("");
    setErr("");

    if (!text.trim()) {
      setErr("Tulis deskripsi transaksi dulu.");
      return;
    }

    setBusyPredict(true);
    try {
      const p = await api("/predict", {
        method: "POST",
        body: JSON.stringify({ text: text.trim() }),
      });
      setPred(p);
      setChosenCat(p?.category || "needs");
    } catch (e2) {
      setErr(e2?.message || "Predict gagal");
    } finally {
      setBusyPredict(false);
    }
  }

  async function saveTransactionRequest() {
    setMsg("");
    setErr("");

    const n = Number(amount);
    if (!text.trim()) return setErr("Teks transaksi kosong.");
    if (!Number.isFinite(n) || n <= 0) return setErr("Nominal harus angka > 0.");

    setBusySave(true);
    try {
      await api("/transactions", {
        method: "POST",
        body: JSON.stringify({
          text: text.trim(),
          amount: Math.floor(n),
          category: chosenCat,
          // confidence: pred?.confidence ?? null, // aktifin kalau backend float
        }),
      });

      setMsg(`✅ Tersimpan ke ${chosenCat} (+Rp ${formatIDR(Math.floor(n))})`);
      setText("");
      setAmount("");
      setPred(null);

      await loadAll();
    } catch (e2) {
      setErr(e2?.message || "Gagal simpan transaksi");
    } finally {
      setBusySave(false);
    }
  }

  // UI styles
  const pageStyle = {
    minHeight: "100vh",
    padding: 24,
    color: "#fff",
    background:
      "radial-gradient(1200px 600px at 20% 10%, rgba(124,58,237,0.35), transparent), radial-gradient(1200px 600px at 90% 10%, rgba(34,197,94,0.25), transparent), #0b1020",
  };

  const pillStyle = (type) => {
    const isErr = type === "err";
    const isOk = type === "ok";
    return {
      padding: 12,
      borderRadius: 12,
      border: isErr
        ? "1px solid rgba(239,68,68,0.35)"
        : isOk
        ? "1px solid rgba(34,197,94,0.35)"
        : "1px solid rgba(255,255,255,0.12)",
      background: isErr
        ? "rgba(239,68,68,0.12)"
        : isOk
        ? "rgba(34,197,94,0.12)"
        : "rgba(0,0,0,0.18)",
      color: isErr ? "#fecaca" : isOk ? "#bbf7d0" : "#fff",
    };
  };

  const inputStyle = {
    padding: 12,
    borderRadius: 12,
    border: "1px solid rgba(255,255,255,0.18)",
    background: "rgba(255,255,255,0.06)",
    color: "#fff",
    outline: "none",
  };

  const btnStyle = (variant = "soft") => {
    const base = {
      height: 44,
      padding: "0 14px",
      borderRadius: 12,
      border: "1px solid rgba(255,255,255,0.18)",
      cursor: "pointer",
      fontWeight: 800,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      lineHeight: 1,
      whiteSpace: "nowrap",
      fontFamily: "inherit", // ✅ biar font button sama
    };

    if (variant === "primary") {
      return {
        ...base,
        background: "linear-gradient(90deg, rgba(124,58,237,0.9), rgba(34,197,94,0.8))",
        color: "#fff",
        fontWeight: 900,
      };
    }

    return {
      ...base,
      background: "rgba(255,255,255,0.06)",
      color: "#fff",
    };
  };

  return (
    <div style={pageStyle} className="dash-page">
      <style>{`
        .dash-wrap{max-width:1100px;margin:0 auto;display:grid;gap:16px}
        .dash-header{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:flex-start}
        .dash-actions{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
        .dash-topgrid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
        .dash-meters{display:grid;grid-template-columns:1fr 1fr;gap:14px}

        @media (max-width: 900px){
          .dash-topgrid{grid-template-columns:1fr}
        }

        @media (max-width: 720px){
          .dash-page{padding:16px !important}
          .dash-actions{width:100%}
          .dash-actions > button{flex:1 1 auto}
          .dash-meters{grid-template-columns:1fr}
        }

        @media (max-width: 420px){
          .dash-actions > button{width:100%}
        }
      `}</style>

      <div className="dash-wrap">
        {/* header */}
        <div className="dash-header">
          <div>
            <div style={{ opacity: 0.8, fontSize: 13 }}>Financial Planning</div>
            <h1 style={{ margin: "6px 0 0", fontSize: 34 }}>Dashboard</h1>

            {/* ✅ hello user dari DB */}
            <div style={{ marginTop: 8, opacity: 0.9, fontSize: 14 }}>
              Hello{me?.username ? `, ${me.username}` : ""} 👋
            </div>

            {/* ✅ simulasi bulan (buat testing) */}
            <div style={{ marginTop: 10, display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
              <div style={{ opacity: 0.75, fontSize: 13 }}>Periode dashboard:</div>
              <input
                type="month"
                value={ym}
                onChange={(e) => setYm(e.target.value)}
                style={{
                  ...inputStyle,
                  height: 44,
                  padding: "0 12px",
                  width: 160,
                  fontFamily: "inherit",
                }}
              />
              <div style={{ opacity: 0.7, fontSize: 12 }}>
                (Ganti bulan = “reset pemakaian” karena hitung per-bulan)
              </div>
            </div>
          </div>

          <div className="dash-actions">
            <button onClick={() => nav("/setup-income")} style={btnStyle("soft")}>
              Edit Income
            </button>
            <button onClick={() => nav("/transactions")} style={btnStyle("soft")}>
              Riwayat
            </button>
            <button onClick={() => nav("/reports")} style={btnStyle("soft")}>
              Laporan
            </button>
            <button onClick={logout} style={btnStyle("soft")}>
              Logout
            </button>
          </div>
        </div>

        {/* alerts */}
        {err && <div style={pillStyle("err")}>{err}</div>}
        {msg && <div style={pillStyle("ok")}>{msg}</div>}

        {/* top cards */}
        <div className="dash-topgrid">
          <Card title="Income Bulanan">
            <div style={{ fontSize: 28, fontWeight: 900 }}>Rp {formatIDR(income)}</div>
            <div style={{ opacity: 0.75, marginTop: 6, fontSize: 13 }}>
              Total budget (berdasarkan target): Rp {formatIDR(totalBudget)}
            </div>
            {hasDebt && (
              <div style={{ marginTop: 10, fontSize: 13, opacity: 0.9 }}>
                ⚠️ Terdeteksi hutang → target <b>Debts 20%</b>, <b>Invests 0%</b>
              </div>
            )}
          </Card>

          <Card title="Input Transaksi">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                doPredictRequest(); // TANPA KONFIRMASI PREDICT
              }}
              style={{ display: "grid", gap: 10 }}
            >
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder='contoh: "bayar cicilan mobil"'
                style={{ ...inputStyle, fontFamily: "inherit" }}
              />

              <input
                value={amount}
                onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))}
                placeholder='nominal (contoh: 250000)'
                inputMode="numeric"
                style={{ ...inputStyle, fontFamily: "inherit" }}
              />

              {/* PREVIEW NOMINAL */}
              <div style={{ marginTop: -6, fontSize: 13, opacity: 0.85 }}>
                Preview: <b>Rp {formatIDR(Number(amount || 0))}</b>
              </div>

              <button
                disabled={busyPredict}
                style={{ ...btnStyle("soft"), opacity: busyPredict ? 0.7 : 1 }}
              >
                {busyPredict ? "Predicting..." : "Predict Category"}
              </button>

              {pred && (
                <div
                  style={{
                    marginTop: 6,
                    padding: 12,
                    borderRadius: 12,
                    border: "1px solid rgba(255,255,255,0.12)",
                    background: "rgba(0,0,0,0.18)",
                    display: "grid",
                    gap: 10,
                  }}
                >
                  <div style={{ fontSize: 13, opacity: 0.9 }}>
                    Prediksi: <b>{pred.category}</b>{" "}
                    {pred.confidence != null && (
                      <span>(conf {Math.round((pred.confidence || 0) * 100)}%)</span>
                    )}
                  </div>

                  <div style={{ display: "grid", gap: 6 }}>
                    <div style={{ fontSize: 13, opacity: 0.85 }}>Edit kategori</div>
                    <select
                      value={chosenCat}
                      onChange={(e) => setChosenCat(e.target.value)}
                      style={{
                        height: 44,
                        padding: "0 12px",
                        borderRadius: 12,
                        border: "1px solid rgba(255,255,255,0.18)",
                        background: "rgba(255,255,255,0.06)",
                        color: "#fff",
                        outline: "none",
                        fontFamily: "inherit",
                      }}
                    >
                      {CATS.map((c) => (
                        <option key={c} value={c} style={{ color: "#000" }}>
                          {cap(c)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <button
                    type="button"
                    onClick={() => {
                      openConfirm({
                        title: "Simpan transaksi?",
                        message: (
                          <div style={{ display: "grid", gap: 10 }}>
                            <div style={{ opacity: 0.85 }}>Pastikan data sudah benar sebelum disimpan.</div>
                            <div
                              style={{
                                padding: 12,
                                borderRadius: 12,
                                background: "rgba(255,255,255,0.06)",
                                border: "1px solid rgba(255,255,255,0.12)",
                              }}
                            >
                              <div>
                                <b>Teks:</b> {text || "-"}
                              </div>
                              <div>
                                <b>Nominal:</b> Rp {formatIDR(Number(amount || 0))}
                              </div>
                              <div>
                                <b>Kategori:</b> {chosenCat}
                              </div>
                              {pred?.confidence != null && (
                                <div>
                                  <b>Confidence:</b> {Math.round((pred.confidence || 0) * 100)}%
                                </div>
                              )}
                            </div>
                          </div>
                        ),
                        confirmText: "Ya, simpan",
                        cancelText: "Batal",
                        action: async () => {
                          await saveTransactionRequest();
                        },
                      });
                    }}
                    disabled={busySave}
                    style={{ ...btnStyle("primary"), opacity: busySave ? 0.7 : 1 }}
                  >
                    {busySave ? "Saving..." : "Konfirmasi & Simpan"}
                  </button>
                </div>
              )}
            </form>
          </Card>
        </div>

        {/* meters */}
        <Card title="Budget Meters">
          {loading ? (
            <div style={{ opacity: 0.75 }}>Loading...</div>
          ) : (
            <div className="dash-meters">
              <Meter label="Needs" targetPct={targets.needs} income={income} spent={summary.needs} />
              <Meter label="Wants" targetPct={targets.wants} income={income} spent={summary.wants} />
              <Meter label="Debts" targetPct={targets.debts} income={income} spent={summary.debts} />
              <Meter label="Savings" targetPct={targets.savings} income={income} spent={summary.savings} />
              <Meter label="Invests" targetPct={targets.invests} income={income} spent={summary.invests} />
            </div>
          )}
        </Card>
      </div>

      {/* confirm modal global */}
      <ConfirmModal
        open={confirm.open}
        title={confirm.title}
        message={confirm.message}
        confirmText={confirm.confirmText}
        cancelText={confirm.cancelText}
        danger={confirm.danger}
        onCancel={closeConfirm}
        onConfirm={async () => {
          const act = confirm.action;
          closeConfirm();
          if (typeof act === "function") await act();
        }}
      />
    </div>
  );
}
